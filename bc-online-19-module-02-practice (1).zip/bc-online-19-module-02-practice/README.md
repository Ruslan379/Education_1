# bootcamp-19-online

---

## Module 02 theory + practice

Посилання на [макет](https://www.figma.com/file/BfzH6wguaWDV03mZrJckjK/Barbershop_v1?node-id=1%3A2 "BarberShop").
